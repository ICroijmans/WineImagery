
Created 2019-08-09 by Ilja Croijmans, i.m.croijmans@uu.nl

This data archive belongs to the publication "Expertise shapes multimodal imagery for wine" by Ilja Croijmans, Laura J. Speed, Artin Arshamian & Asifa Majid. 

This dataset contains data of wine imagery in experts, novices, wine students and matched controls. The abstract explaining the findings: 

Taste and smell seem hard to imagine, but people differ in this ability. 
We investigate whether experts are better able to imagine smells and tastes because they have learnt the ability or whether they are better imagers in the first place, 
and so become experts. To test this, we compared a group of wine experts to yoked novices using a battery of questionnaires. 
We show for the first time that experts reported greater vividness of wine imagery, with no difference in vividness across sensory modalities; 
whereas novices had more vivid visual than taste or odor wine imagery. Critically, we followed a group of students commencing a wine course and control participants. 
Students and controls did not differ before the course, but after the wine course, students reported more vivid wine imagery. 
We provide evidence that expertise improves imagery, exemplifying the extent of plasticity of cognition underlying the chemical senses.

The archive contains four files, 2 sets of a SPSS data file and a corresponding SPSS syntax file: 
MIQE_1ExNov_AllData_20190611.SAV - datafile for first study reported in the manuscript, comparing wine experts and matched novices on several measures
MIQE 1ExNovSyntax 20190603.SPS - Syntax file for first study reported in the manuscript, including all analyses reported in the manuscript
MIQE_2PrePost_AllData_20190611.SAV - datafile for second study reported in the manuscript, comparing wine students and matched novices on several measures, before and after an intensive course on wine
MIQE 2PrePostSyntax 20190618.SPS - Syntax file for second study reported in the manuscript, including all analyses reported in the manuscript

Please note this dataset is published under CC BY 4.0 license